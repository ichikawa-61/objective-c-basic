//
//  CameraUtil.m
//  2-5-3
//
//  Created by Manami Ichikawa on 4/4/17.
//  Copyright © 2017 Manami Ichikawa. All rights reserved.
//

#import "CameraUtil.h"
#import "PhotoCaptureViewController.h"

@implementation CameraUtil


-(AVCaptureDevice *)findDevice{
    
    
//    return [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo,
//            ];
    
    AVCaptureDevice * camera = [AVCaptureDevice defaultDeviceWithDeviceType:AVCaptureDeviceTypeBuiltInWideAngleCamera mediaType: AVMediaTypeVideo position:AVCaptureDevicePositionBack];
//            
    return camera;
            


}

//-(AVCaptureVideoPreviewLayer *)createView:(AVCaptureSession*)session Device:(AVCaptureDevice*)device{

-(AVCaptureVideoPreviewLayer *)createView:session Device :(AVCaptureDevice*)device{
    
    
    NSError *error;
    AVCaptureDeviceInput *videoInput = [[AVCaptureDeviceInput alloc]initWithDevice:(AVCaptureDevice *)device error:&error];
    

    AVCaptureSession *captureSession = session;
    [captureSession addInput:videoInput];
    [captureSession addOutput:self.imageOutput];
    
    AVCaptureVideoPreviewLayer * layer = [AVCaptureVideoPreviewLayer layerWithSession:(AVCaptureSession *)session];
    
    return layer;
    
}

-(void)takePhoto{
    
    AVCapturePhotoSettings *settings = [[AVCapturePhotoSettings alloc]init];
    
    [self.imageOutput capturePhotoWithSettings:(AVCapturePhotoSettings *)settings delegate:self];

}
     
     
     
-(void)savePhoto: (CMSampleBufferRef*)imageDataBuffer{
    
    NSData *imageData = [AVCapturePhotoOutput JPEGPhotoDataRepresentationForJPEGSampleBuffer:*imageDataBuffer previewPhotoSampleBuffer:nil];
    
//    UIImage *photoImage = [[UIImage alloc]initWithData:imageData];
    
    
    

                                    
 
}

-(void)captureOutput:(AVCapturePhotoOutput *)captureOutput didFinishProcessingPhotoSampleBuffer:(CMSampleBufferRef)photoSampleBuffer previewPhotoSampleBuffer:(CMSampleBufferRef)previewPhotoSampleBuffer resolvedSettings:(AVCaptureResolvedPhotoSettings *)resolvedSettings bracketSettings:(AVCaptureBracketedStillImageSettings *)bracketSettings error:(NSError *)error{
    
    
    if(error){
        NSLog(@"取れてないよ");
    
    }

    NSLog(@"ok");

}



@end
