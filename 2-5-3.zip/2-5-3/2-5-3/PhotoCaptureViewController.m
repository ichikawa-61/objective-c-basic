//
//  ViewController.m
//  2-5-3
//
//  Created by Manami Ichikawa on 4/3/17.
//  Copyright © 2017 Manami Ichikawa. All rights reserved.
//

#import "PhotoCaptureViewController.h"
#import "CameraUtil.h"
@interface PhotoCaptureViewController ()

//@property AVCapturePhotoOutput   *captureOutput;
//@property AVCapturePhotoSettings *setting;
//@property AVCaptureVideoPreviewLayer *previewLayer;
//@property AVCaptureInput *input;
@property CameraUtil *camera;
//
@property AVCaptureSession *session;
//@property AVCaptureDevice *device;
//@property AVCaptureDeviceInput* deviceInput;

@end

@implementation PhotoCaptureViewController




- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.camera = [[CameraUtil alloc]init];
    
    [self setUpCameraView];
    self.session = [[AVCaptureSession alloc]init];
    [self.session startRunning];
    
}

-(void)setUpCameraView{
    
    AVCaptureDevice *device = [self.camera findDevice];
    
    AVCaptureVideoPreviewLayer *videoLayer = [self.camera createView:self.session Device:device];
    
    if(videoLayer){
    
    videoLayer.frame        = self.cameraView.bounds;
    //videoLayer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    [self.cameraView.layer addSublayer:videoLayer];
    }else{
        NSLog(@"VideoLayerがnil");
    }
   
}


- (IBAction)openCamera:(id)sender {
     [self.camera takePhoto];
}


@end
