//
//  CameraUtil.h
//  2-5-3
//
//  Created by Manami Ichikawa on 4/4/17.
//  Copyright © 2017 Manami Ichikawa. All rights reserved.
//

//#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import <AVFoundation/AVFoundation.h>
@interface CameraUtil : NSObject<AVCapturePhotoCaptureDelegate>

-(AVCaptureDevice *)findDevice ;
-(AVCaptureVideoPreviewLayer *)createView:session Device:(AVCaptureDevice*)device;
@property AVCapturePhotoOutput *imageOutput;



-(void)savePhoto: (CMSampleBufferRef*)imageDataBuffer;
-(void)takePhoto;
@end
